# impotsgouvfrapi
## Usage
clone the project to your machine and then:

```bash
npm i
```

```bash
npm start
```
Make an api request to ../api with json data:

```bash
{
	"numeroFiscal": "xxxxxxxxxxxxx",
	"referenceDeLavis": "xxxxxxxxxxx"
}
```

